import { initializeApp } from 'firebase/app';
import { getAnalytics } from 'firebase/analytics';
import { getFirestore } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
	apiKey: 'AIzaSyCkipuiYpFg15OoWCqIVDv0RrkoLhYQCtc',
	authDomain: 'geografiskhave-17f07.firebaseapp.com',
	projectId: 'geografiskhave-17f07',
	storageBucket: 'geografiskhave-17f07.appspot.com',
	messagingSenderId: '187948113308',
	appId: '1:187948113308:web:9794a4ff59cd05a6b0bc59',
	measurementId: 'G-YBE9R399J2',
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
const db = getFirestore(app);
const auth = getAuth(app);
const storage = getStorage(app);

export { db, auth, storage };
